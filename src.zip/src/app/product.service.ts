import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from './product';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService 
{
  [x: string]: any;
  constructor(private client:HttpClient) { }
  baseUrl="http://localhost:3000/product";
  // baseUrl="http://localhost:8080/product";

  saveRecord(product:Product):Observable<any>
  {
    return this.client.post<Product>(this.baseUrl,product);
  }
  getProductList():Observable<Product[]>
  {
    return this.client.get<Product[]>(this.baseUrl);
  }
  searhProduct(pid:number):Observable<any> 
  {
    return this.client.get<Product[]>(this.baseUrl+"/"+pid);
  }
  deleteProduct(pid:number):Observable<any>
  {
    return this.client.delete<Product[]>(this.baseUrl+"/"+pid);
  }
  updateRecord(product:Product):Observable<any>
  {
    return this.client.put<Product>(this.baseUrl+"/"+product.id,product);
  }
}

