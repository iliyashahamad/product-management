export class Product
{
    id:number;
    name:string;
    brand:string;
    price:number;
}
