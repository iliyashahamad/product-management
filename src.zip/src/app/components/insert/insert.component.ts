import { Component } from '@angular/core';
import { Product } from 'src/app/product';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent 
{

  constructor(private service:ProductService){}

  product=new Product();
  msg:string="";
  success=true;
  save()
  {
    this.service.saveRecord(this.product).subscribe({
      next:data=>{this.msg="Product record has been saved successfully", this.success=true},
      error:er=>{this.msg="Given product id already exists",this.success=false}
    });
  }
}
