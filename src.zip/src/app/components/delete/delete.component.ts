import { Component } from '@angular/core';
import { Product } from 'src/app/product';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent 
{
  constructor(private service:ProductService){}
  product:Product;
  found=false;
  delete=false;
  pid:any;
  msg:string;
  deleteRecord()
  {
    this.delete=true;
    this.service.searhProduct(this.pid).subscribe(
      {
        next:data=>{this.product=data,this.found=true},
        error:er=>{this.found=false;this.msg="Product record does not exist"}
      }
    )
  }
  confirmDelete()
  {
    this.service.deleteProduct(this.pid).subscribe({
      next:data=>{this.msg="Product record has been deleted",this.found=false;this.pid=""}
    })
  }
}
